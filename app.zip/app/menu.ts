export class Menu {
  constructor(
    public menuId:string,
    public menuName:string,
    public menuPrice:number,
    public menuVendor:string,
    public menuCat:string) {
    }
}
