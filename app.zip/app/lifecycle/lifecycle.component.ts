import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-lifecycle',
  templateUrl: './lifecycle.component.html',
  styleUrls: ['./lifecycle.component.css']
})
export class LifecycleComponent implements OnInit, OnChanges, 
  OnDestroy, AfterViewInit, AfterViewChecked, 
  AfterContentInit, AfterContentChecked   {
  
  @Input()
  simpleInput :string = "hello";
  constructor() { }

  ngOnInit() {
    console.log("onInit")
  }

  ngOnChanges(changes:SimpleChanges):void{
    console.log("ng on change");
  }

  ngOnDestroy():void{
    console.log("ng on Destroy");
  }

  ngAfterViewInit():void{
    console.log("after view init");
  }

  ngAfterViewChecked(){
    console.log("after view checked");
  }

  ngAfterContentInit(){
    console.log("after content init");
  }

  ngAfterContentChecked(){
    console.log("after content checked");
  }
}
