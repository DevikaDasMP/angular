import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DatabindingComponent } from './databinding/databinding.component';
import { LifecycleComponent } from './lifecycle/lifecycle.component';
import { HomeComponent } from './home/home.component';
import { ShowallmenuComponent } from './showallmenu/showallmenu.component';
import { MenudetailsComponent } from './menudetails/menudetails.component';


const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'databinding',component:DatabindingComponent},
  {path:'lifecycle',component:LifecycleComponent},
  {path:'showallmenu',component:ShowallmenuComponent},
  {path:'menu/:mId',component:MenudetailsComponent} 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
