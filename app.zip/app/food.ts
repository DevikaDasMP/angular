export interface Food {
  fName:string;
  fCalories:number;
  fVegan?:string;
}
