import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TscComponent } from './tsc/tsc.component';
import { DatabindingComponent } from './databinding/databinding.component';
import { InlineComponent } from './inline/inline.component';
import { LifecycleComponent } from './lifecycle/lifecycle.component';
import { HomeComponent } from './home/home.component';
import { ShowallmenuComponent } from './showallmenu/showallmenu.component';
import { MenudetailsComponent } from './menudetails/menudetails.component';

@NgModule({
  declarations: [
    AppComponent,
    TscComponent,
    DatabindingComponent,
    InlineComponent,
    LifecycleComponent,
    HomeComponent,
    ShowallmenuComponent,
    MenudetailsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
