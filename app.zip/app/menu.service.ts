import { Injectable } from '@angular/core';
import { Menu } from './menu';

@Injectable({
  providedIn: 'root'
})
export class MenuService {
  public menuArr: Menu[];
  constructor() { 
    this.menuArr=[
      new Menu('1001','Idly',20,'500','Vegetarian'),
      new Menu('1002','Dosa',30,'500','Vegetarian'),
      new Menu('1003','Biriyani',100,'501','NonVegetarian'),
      new Menu('1004','Gobi',70,'501','NonVegetarian'),
      new Menu('1005','Paratta',50,'502','NonVegetarian'),
      new Menu('1006','Rice',60,'503','Vegetarian'),
    ];
  }
  getAllMenu():Menu[]{
    return this.menuArr;
  }
  getMenuDetails(argMenuId:string):Menu{
    for(let menu of this.menuArr){
      let c=menu.menuId;
      if(c==argMenuId){
        return menu;
      }
    }
    return null;
  }
  addMenu(argMnu:Menu):void{
    this.menuArr.push(argMnu);
  }
}
