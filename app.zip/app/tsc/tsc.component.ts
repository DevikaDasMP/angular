import { Component, OnInit } from '@angular/core';
import { Food } from '../food';
import { Northindian } from '../northindian';

@Component({
  selector: 'app-tsc',
  templateUrl: './tsc.component.html',
  styleUrls: ['./tsc.component.css']
})
export class TscComponent implements OnInit {
  mynameClassScope:string;
  private ni:Northindian=new Northindian("Lunch","rice",100,"Vegan");

  constructor() { }

  ngOnInit() {
    let strLocal:string;
    strLocal="This is a string";
    console.log(strLocal);
    
    this.mynameClassScope='Geetha';
    console.log("my name is :"+this.mynameClassScope);
    
    let num: number;
    num=5;
    console.log("value is :"+num);
    
    let aBoolean: boolean;
    aBoolean=false;
    console.log("aBoolean value is :"+aBoolean);

    let myFood:Food = {fName:"Dosa",fCalories:300};
    console.log("our food details :"+myFood.fName +" has calories : "+myFood.fCalories);

    let dispmsg=(msg)=>{console.log(msg)}
    dispmsg(this.ni);

    let val :number[] =[66,77,88,99];
    for(let i of val)
      console.log(i);
    for(let x in val)
      console.log(x);
  }
}
