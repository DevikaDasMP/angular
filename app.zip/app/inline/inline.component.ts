import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inline',
  template: `
    <p class='boldClass'>
      inline works!
    </p>
  `,
  styles: [`
  .boldClass{
    font-weight:bold;
  }`]
})
export class InlineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
