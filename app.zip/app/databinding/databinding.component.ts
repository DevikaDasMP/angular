import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-databinding',
  templateUrl: './databinding.component.html',
  styleUrls: ['./databinding.component.css']
})
export class DatabindingComponent implements OnInit {

  strInterpolation: string;
  numInterpolation: number=10;
  fname :string;
  constructor() { }

  ngOnInit() {
    this.strInterpolation="Learning String Interpolation";
    this.numInterpolation=99;
    this.fname="Mala";
  }
  myalert(value:String):void{
    alert(value);
  }

}
