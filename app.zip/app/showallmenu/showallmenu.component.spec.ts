import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowallmenuComponent } from './showallmenu.component';

describe('ShowallmenuComponent', () => {
  let component: ShowallmenuComponent;
  let fixture: ComponentFixture<ShowallmenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowallmenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowallmenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
