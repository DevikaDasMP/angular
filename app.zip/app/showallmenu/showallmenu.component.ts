import { Component, OnInit } from '@angular/core';
import { Menu } from '../menu';
import { MenuService } from '../menu.service';

@Component({
  selector: 'app-showallmenu',
  templateUrl: './showallmenu.component.html',
  styleUrls: ['./showallmenu.component.css']
})
export class ShowallmenuComponent implements OnInit {
  menuItems:Menu[];
  constructor(private menuserv:MenuService) { }

  ngOnInit() {
    this.menuItems=this.menuserv.getAllMenu();
    console.log(this.menuItems);
  }

}
