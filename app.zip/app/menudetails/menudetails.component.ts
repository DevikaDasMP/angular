import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MenuService } from '../menu.service';
import { Menu } from '../menu';

@Component({
  selector: 'app-menudetails',
  templateUrl: './menudetails.component.html',
  styleUrls: ['./menudetails.component.css']
})
export class MenudetailsComponent implements OnInit {
  menudetails:Menu;
  birthday=new Date(1997,11,20);
  constructor(
    private _router:Router,
    private _menuService:MenuService,
    private _activatedRoute:ActivatedRoute) { }

  ngOnInit() {
    let menuCode:string=
    this._activatedRoute.snapshot.params['mId'];
    console.log('the value of url is  '+menuCode);
    this.menudetails=this._menuService.getMenuDetails(menuCode);
    console.log(this.menudetails);
  }
  gotoShowAllMenu():void {
    this._router.navigate(['/showallmenu'])
  }

}
