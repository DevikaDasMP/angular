import { Food } from './food';

export class Northindian implements Food{
  constructor(private special:string, public fName:string, public fCalories:number,public fvegan?:string){
  }
}
