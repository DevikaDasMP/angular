import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  subscription:Subscription;
  param:any;
  pSnapshotWay:any;

  constructor(private _router:Router,private acR: ActivatedRoute) {
    this.subscription=
    _router.routerState.root.queryParams.subscribe(
      (queryParams:any)=>this.param=queryParams['myKey']
    );
    this.pSnapshotWay=this.acR.snapshot.queryParamMap.get("myKey")
    }
    
  
    


  ngOnInit() {
  }

}
